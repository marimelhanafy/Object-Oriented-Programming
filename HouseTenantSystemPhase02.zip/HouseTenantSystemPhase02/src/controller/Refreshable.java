package controller;

public interface Refreshable {
 void refresh();
}
