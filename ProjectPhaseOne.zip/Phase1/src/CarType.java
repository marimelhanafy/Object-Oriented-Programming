/**
 * @author ...
 * @date ...
 *
 */
public enum CarType {
	SEDAN, SUV, VAN, TRUCK;
}
